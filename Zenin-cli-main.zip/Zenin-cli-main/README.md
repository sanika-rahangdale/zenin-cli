# 🐜 Meruem CLI v2.0

> **AI-Powered Cybersecurity Terminal Assistant**
> *A smart shell wrapper built for pentesters & CTF players*

---

## 📋 Table of Contents

- [What is Meruem?](#what-is-meruem)
- [Features](#features)
- [File Structure](#file-structure)
- [Installation](#installation)
- [Getting API Keys (Free)](#getting-api-keys-free)
- [Adding API Keys](#adding-api-keys)
- [Selecting AI Provider](#selecting-ai-provider)
- [All Commands](#all-commands)
- [AI Commands Demo](#ai-commands-demo)
- [Safety System](#safety-system)
- [Troubleshooting](#troubleshooting)

---

## What is Meruem?

Meruem sits between you and your terminal. Every command you run passes through it first, and it will:

- **Catch typos** before they turn destructive (`namp` → `nmap`)
- **Flag risky commands** before something like `rm -rf /` executes
- **Recommend follow-up tools** once a scan finishes (open port 80 → try `gobuster`)
- **Break down commands** so every flag actually makes sense
- **Answer security questions** on demand using a free AI backend
- **Draft your report** straight from the session log

---

## Features

| Feature | How it works |
|---|---|
| ✏️ Typo Correction | Fuzzy-matches mistyped commands against known tools |
| ⚠️ Danger Detection | Flags or blocks destructive patterns (wipe commands, permission bombs, fork bombs) |
| 💡 Pentest Suggestions | Recommends the next tool based on prior scan output |
| 📖 Command Explainer | Breaks a command and its flags down line by line |
| 🤖 AI Q&A | Ask a plain-English security question, get an answer |
| 🤖 AI Explain | Deeper, AI-generated breakdown of any command |
| 🤖 AI Suggestions | AI reviews your whole session and proposes next steps |
| 📝 Auto Writeup | Turns your session history into a report draft |
| 🗄️ History | Every command logged to SQLite with a timestamp |
| 🔄 AI Fallback | If the AI backend is unreachable, rule-based logic still runs |

---

## File Structure

```
meruem-cli/
│
├── run.py                    ← 🚀 Entry point — launch from here
├── cli.py                    ← REPL loop (prompt_toolkit)
├── interceptor.py            ← Core pipeline: routes every command
├── ai_engine.py              ← AI routing + multi-provider fallback
├── config.py                 ← API key storage & active provider
│
├── analyzer.py               ← Typo detection (difflib)
├── security.py               ← Dangerous command detection
├── suggestions.py            ← Rule-based pentest suggestions
├── history.py                ← SQLite command history
├── explain.py                ← Command explanation engine
├── writeup.py                ← Report generator
│
├── rules.json                ← Patterns, typo map, explanations
├── requirements.txt          ← Python dependencies
├── .env                       ← Your API keys (auto-created, never commit)
├── .env.example                ← Key template
├── .gitignore                  ← Keeps .env out of version control
│
└── providers/
    ├── groq.py                ← Groq (Llama 3.3) — recommended, free
    ├── gemini.py               ← Google Gemini 2.0 Flash
    ├── openrouter.py           ← OpenRouter (free-tier models)
    └── ollama.py               ← Local Ollama, fully offline
```

**Created automatically at runtime:**
- `meruem.db` — SQLite history database
- `meruem_config.json` — active provider setting
- `.env` — your API keys (written by `set-api`)

---

## Installation

### Step 1 — Get the files

```bash
# Clone it
git clone https://github.com/Vk-23/Zenin-cli.git meruem-cli
cd meruem-cli

# or unzip the download, then
cd meruem-cli
```

### Step 2 — Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3 — Install the one dependency

```bash
pip install prompt_toolkit
```

### Step 4 — Add a shell alias (one-time)

```bash
echo "alias meruem='source ~/path/to/meruem-cli/venv/bin/activate && python3 ~/path/to/meruem-cli/run.py'" >> ~/.zshrc
source ~/.zshrc
```

> Swap `~/path/to/meruem-cli` for wherever you placed the folder.

### Step 5 — Launch

```bash
meruem
```

Expected output:

```
  ╔══════════════════════════════════════╗
  ║   🐜  Meruem CLI  v2.0.0             ║
  ║   AI-Powered Cybersecurity Terminal  ║
  ╚══════════════════════════════════════╝

  AI Provider : not set — run: set-api groq
```

---

## Getting API Keys (Free)

Only one key is required to unlock AI features — pick whichever provider suits you.

### 🥇 Groq (Recommended)

Fastest response times, strong free-tier model, generous daily limit.

1. Visit **https://console.groq.com**
2. Sign up (Google or GitHub)
3. **API Keys** → **Create API Key**
4. Copy the key — starts with `gsk_`

### Google Gemini

Backed by Google's infrastructure, solid free daily quota.

1. Visit **https://aistudio.google.com/app/apikey**
2. Sign in with a Google account
3. **Create API Key**
4. Copy the key — starts with `AIza`

### OpenRouter

Gateway to many models, including no-cost ones, no card required.

1. Visit **https://openrouter.ai**
2. Sign up → **Keys**
3. **Create Key**
4. Copy the key — starts with `sk-or-`

### Ollama (Local, offline)

No key needed, runs entirely on your machine.

```bash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3
ollama serve
```

---

## Adding API Keys

Once Meruem is running:

```
[meruem] ~ ❯ set-api groq
```

You'll be prompted to paste the key (input hidden, like a password). Once saved it's stored in `.env` and only ever shown masked, e.g. `gsk_****abcd`.

Add as many providers as you like:

```
[meruem] ~ ❯ set-api groq
[meruem] ~ ❯ set-api gemini
[meruem] ~ ❯ set-api openrouter
```

---

## Selecting AI Provider

```
[meruem] ~ ❯ ai-provider groq
[meruem] ~ ❯ ai-provider gemini
[meruem] ~ ❯ ai-provider openrouter
[meruem] ~ ❯ ai-provider ollama
```

Check what's configured and what's active:

```
[meruem] ~ ❯ ai status
```

---

## All Commands

### 🤖 AI Commands

| Command | Description |
|---|---|
| `ask <question>` | Free-form security Q&A |
| `ai explain <command>` | AI breakdown of a command |
| `ai suggest` | AI reviews the session, proposes next steps |
| `ai writeup` | AI-generated report narrative |
| `ai status` | Show configured providers and the active one |

### 🔑 API Key Management

| Command | Description |
|---|---|
| `set-api groq` | Store a Groq API key |
| `set-api gemini` | Store a Gemini API key |
| `set-api openrouter` | Store an OpenRouter API key |
| `set-api ollama` | Show local Ollama setup steps |
| `ai-provider <name>` | Switch the active provider |

### 🛠️ Built-in Tools

| Command | Description |
|---|---|
| `explain <cmd> [flags]` | Rule-based command/flag breakdown |
| `writeup` | Print the session writeup |
| `writeup save` | Save the writeup as a `.md` file |
| `history` | Show the last 20 commands |
| `history search <keyword>` | Search command history |
| `meruem freq` | Show most-used commands |
| `meruem help` | Full command reference |
| `exit` / `quit` | Exit Meruem |

---

## AI Commands Demo

### Ask a question

```
[meruem] ~ ❯ ask how do I enumerate SMB shares on a target

  Suggestion: Enumerate shares with smbclient
  Reason: Read-only, no auth required
  Risk: Low

  [1] smbclient -L //TARGET -N
  Run it? [y/N]: y
```

### AI-explain a command

```
[meruem] ~ ❯ ai explain nmap -sS -sV -A -p- TARGET

  -sS  SYN scan (stealth), no full handshake
  -sV  Probes open ports for service/version info
  -A   OS detection + scripts + traceroute, all at once
  -p-  Scans all 65535 ports instead of the default top 1000

  Risk: Noisy — easily flagged by an IDS. Only run against
  systems you're authorized to test.
```

### AI-suggest next steps

```
[meruem] ~ ❯ ai suggest

  Based on your session (ports 22, 80, 3306 open):

  1. Enumerate the web server for hidden paths
  2. Check the database for default credentials
  3. Fingerprint the web framework in use

  <cmd>gobuster dir -u http://TARGET -w common.txt</cmd>
  <cmd>mysql -h TARGET -u root -p</cmd>
```

### Generate a writeup

```
[meruem] ~ ❯ ai writeup

  Executive Summary
  ...

  Findings
  - Port 80: outdated Apache, directory traversal possible
  - Port 3306: default DB credentials accepted

  Save as .md file? [y/N]:
```

---

## Safety System

Every AI-suggested command passes through the same pipeline as anything you type manually:

```
AI proposes a command
        ↓
  Shown to you for review
        ↓
  You confirm (y/N)
        ↓
  Typo check (analyzer.py)
        ↓
  Danger check (security.py)
        ↓
  Execute
```

**The AI never executes anything on its own.** Confirmation is required every time, and the danger check still runs even after you say yes.

### Commands Meruem will warn about

| Pattern | Risk Level |
|---|---|
| `rm -rf /` or `rm -rf ~` | CRITICAL — blocked by default |
| `chmod 777 *` | HIGH — requires confirmation |
| `dd if=... of=/dev/...` | CRITICAL — blocked by default |
| `curl URL \| sh` | HIGH — requires confirmation |
| Fork bombs | CRITICAL — blocked by default |

---

## Troubleshooting

### `source: no such file or directory: venv/bin/activate`
Your alias points to the wrong path — remove and re-add it with the correct location:
```bash
sed -i '/alias meruem/d' ~/.zshrc
echo "alias meruem='source ~/path/to/meruem-cli/venv/bin/activate && python3 ~/path/to/meruem-cli/run.py'" >> ~/.zshrc
source ~/.zshrc
```

### `No module named 'prompt_toolkit'`
```bash
cd ~/path/to/meruem-cli
source venv/bin/activate
pip install prompt_toolkit
```

### Provider returns a 404 / model-not-found error
Model names change over time — open the relevant file in `providers/` and update the model string to whatever the provider currently lists as active.

### `Ollama not reachable at localhost:11434`
```bash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3
ollama serve
```

### AI not responding at all
Run `ai status` to see which providers have keys configured. If none do, run `set-api groq` and grab a free key from https://console.groq.com.

---

## Security Notes

- **Never commit `.env`** — it holds your API keys and is excluded via `.gitignore` by default.
- Keys are stored with `chmod 600` — only your user can read the file.
- Keys are always masked in output, e.g. `gsk_****abcd` — never printed in full.
- AI features are optional. Meruem runs completely fine with no key configured, falling back to rule-based logic.

---

## Tech Stack

| Component | Technology |
|---|---|
| Terminal UI | `prompt_toolkit` |
| AI providers | Pure `urllib` — no SDK required |
| Command history | `sqlite3` (stdlib) |
| Typo correction | `difflib` (stdlib) |
| Key storage | `.env`, `chmod 600` |
| Execution | `subprocess` + `os.system` |

Only one external dependency to install: `prompt_toolkit`.

---

## License

MIT — free for personal and commercial use.

---

*Meruem CLI*